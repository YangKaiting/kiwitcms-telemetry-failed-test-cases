from django.apps import AppConfig


class TelemetrypluginConfig(AppConfig):
    name = 'telemetryPlugin'
